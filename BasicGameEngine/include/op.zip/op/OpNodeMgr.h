#ifndef OPNODEMGR_H
#define OPNODEMGR_H

#include <memory>
#include <vector>
#include "OpNode.h"
#include "IOperate.h"

// OpNodeMgr class definition
class OpNodeMgr {
public:
    // Constructor and Destructor
    OpNodeMgr();
    ~OpNodeMgr();

    // Methods to manage OpNodes
    void addOpNode(const std::shared_ptr<OpNode>& node);
    void removeOpNode(const std::shared_ptr<OpNode>& node);

    // Methods to manage operations on nodes
    void executeAllOperations();

    // Find nodes by key
    std::shared_ptr<OpNode> findNodeByKey(const std::string& key);

private:
    std::vector<std::shared_ptr<OpNode>> nodes_;  // Collection of nodes managed by this manager
};

#endif // OPNODEMGR_H
