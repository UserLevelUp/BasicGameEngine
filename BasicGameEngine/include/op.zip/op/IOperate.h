#ifndef IOPERATE_H
#define IOPERATE_H

#include <string>
#include <memory>

// Forward declaration
class OpNode;

// IOperate interface definition
class IOperate {
public:
    virtual ~IOperate() = default;

    // Pure virtual methods to be implemented by concrete operators
    virtual std::string getSymbol() const = 0;
    virtual std::shared_ptr<OpNode> operate(std::shared_ptr<OpNode> node) = 0;

    // A method to check the type of operation
    virtual std::string getType() const = 0;
};

#endif // IOPERATE_H
