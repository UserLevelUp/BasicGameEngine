#ifndef OPNODE_H
#define OPNODE_H

#include <string>
#include <vector>
#include <memory>

// Forward declaration
class IOperate;

// OpNode class definition
class OpNode {
public:
    // Constructors
    OpNode(const std::string& key, const std::string& value);

    // Destructor
    ~OpNode();

    // Getters and setters
    const std::string& getKey() const;
    void setKey(const std::string& key);

    const std::string& getValue() const;
    void setValue(const std::string& value);

    // Methods for child nodes management
    void addChild(const std::shared_ptr<OpNode>& child);
    const std::vector<std::shared_ptr<OpNode>>& getChildren() const;

    // Methods for operations
    void addOperation(const std::shared_ptr<IOperate>& operation);
    const std::vector<std::shared_ptr<IOperate>>& getOperations() const;

    // Executes all operations in sequence
    void executeOperations();

private:
    std::string key_;  // The unique key identifying this node
    std::string value_;  // The value or state stored in this node
    std::vector<std::shared_ptr<OpNode>> children_;  // Child nodes
    std::vector<std::shared_ptr<IOperate>> operations_;  // Operations associated with this node
};

#endif // OPNODE_H
